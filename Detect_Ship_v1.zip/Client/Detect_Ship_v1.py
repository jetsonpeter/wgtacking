import os
import cv2
import onnxruntime as ort
import numpy as np
import datetime
import time
import serial
import socket
from deep_sort.deep_sort import DeepSort

# Suppress TensorFlow loading messages
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


MODEL_NAME = 'yolov9ssc'  
PATH_TO_FROZEN_GRAPH = MODEL_NAME + '.onnx' 


deepsort = DeepSort("deep_sort/model_weights.ckpt", max_dist=0.2, min_confidence=0.3, nms_max_overlap=1.0, max_iou_distance=0.7)


def find_orientation(B_median_point, I_median_point, division):
    orientation = (B_median_point - I_median_point) // division
    return orientation


def box_image(np_image, boxes, scores, classes, orientation_num, aim_num):
    flag = 0  
    sp = np_image.shape
    im_height, im_width = sp[0], sp[1]
    orientation = 0
    detected_num = 0
    num_ = 0
    label_boat = 'boat'

    det_boxes = []
    det_scores = []
    for i, index in enumerate(classes):
        if index == 9:  
            flag = 1
            aim_box = boxes[i]
            aim_score = scores[i] * 100

            left, right, top, bottom = (
                int(aim_box[1] * im_width),
                int(aim_box[3] * im_width),
                int(aim_box[0] * im_height),
                int(aim_box[2] * im_height)
            )

            det_boxes.append([left, top, right - left, bottom - top])  
            det_scores.append(aim_score / 100.0)  


            box_median_point = (right + left) // 2
            image_median_point = im_width // 2
            division = im_width // orientation_num
            orientation = find_orientation(box_median_point, image_median_point, division)


            cv2.rectangle(np_image, (left, top), (right, bottom), (0, 255, 0), 2)
            font = cv2.FONT_HERSHEY_SIMPLEX
            np_image = cv2.putText(np_image, '{} {}'.format(label_boat, orientation), (left, top), font, 1, (255, 0, 0), 1)

            detected_num += 1
            if detected_num == aim_num:
                break
    return np_image, det_boxes, det_scores, orientation, flag


def data_trans(orientation, flag):
    if flag == 1:
        orientation_LorR = 0 if orientation < 0 else 1
        orientation = abs(orientation)
        data_out = (str(flag) + str(orientation_LorR) + (f"{orientation:02}")).encode()
    else:
        data_out = '0000'.encode()
    return data_out


def add_time(time_now, addtime):
    return datetime.datetime.now() + datetime.timedelta(seconds=addtime)


def main():

    session = ort.InferenceSession(PATH_TO_FROZEN_GRAPH)


    SetUp = cv2.FileStorage('SetUp.xml', cv2.FileStorage_READ)
    if not SetUp.isOpened():
        print("error：NO  SetUp.xml")
        return

    camera_ip = SetUp.getNode('Camera_ip').string()
    work_time = int(SetUp.getNode('work_time_seconds').real())
    break_time = int(SetUp.getNode('break_time_seconds').real())
    orientation_num = int(SetUp.getNode('orientation_num').real())
    aim_num = 1
    STORAGE_LOCATION = SetUp.getNode('Storage_location').string()
    port_p = SetUp.getNode('Port').string()
    bps_p = int(SetUp.getNode('Bps').real())
    timeout_p = int(SetUp.getNode('TimeOut').real())
    timeout_p = None if timeout_p == -1 else timeout_p

    server_ip = SetUp.getNode('Server_IP').string()
    server_port = int(SetUp.getNode('Server_Port').real())
    send_imagesize = int(SetUp.getNode('Send_ImageSize').real())
    send_imagetime = int(SetUp.getNode('Send_ImageTime').real())
    SetUp.release()


    Myserial = serial.Serial(port_p, bps_p, timeout=timeout_p)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((server_ip, server_port))

    while True:
        cap = cv2.VideoCapture(camera_ip)
        if not cap.isOpened():
            print("error：NO camera")
            return

        aim_break_time = add_time(datetime.datetime.now(), work_time)
        send_time_flag = 1

        while (aim_break_time - datetime.datetime.now()).seconds:
            ret, image_np = cap.read()
            if not ret:
                break

            input_blob = cv2.resize(image_np, (640, 640))
            input_blob = np.expand_dims(input_blob.transpose(2, 0, 1), axis=0).astype(np.float32)


            outputs = session.run(None, {session.get_inputs()[0].name: input_blob})
            boxes, scores, classes = outputs


            dst_image, det_boxes, det_scores, orientation, flag_find = box_image(image_np, boxes[0], scores[0], classes[0], orientation_num, aim_num)
            data_serial = data_trans(orientation, flag_find)

            if det_boxes:

                det_boxes = np.array(det_boxes)
                det_scores = np.array(det_scores)
                features = np.array([deepsort.encoder(image_np, det_boxes)])


                tracked_objects = deepsort.update(det_boxes, det_scores, features)
                for track in tracked_objects:
                    track_id = track.track_id
                    left, top, width, height = track.to_tlwh()
                    cv2.rectangle(dst_image, (int(left), int(top)), (int(left + width), int(top + height)), (255, 0, 0), 2)
                    cv2.putText(dst_image, f'ID {track_id}', (int(left), int(top) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

            if Myserial.is_open:
                Myserial.write(data_serial)
            else:
                print("error: ip")
                return

            image_name = STORAGE_LOCATION + datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '.png'
            cv2.imwrite(image_name, dst_image)

            if cv2.waitKey(25) == 27:
                sock.send(b'9999')
                cv2.destroyAllWindows()
                return

        cap.release()
        time.sleep(break_time)
    sock.close()
    Myserial.close()

if __name__ == "__main__":
    main()
