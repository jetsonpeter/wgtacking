import socket
import cv2
import numpy as np


def recv_size_1(sock, count):
     buf = ''
     while count:
        newbuf = sock.recv(count)
        if not newbuf: return None
        newbuf=bytes.decode(newbuf)
        buf += newbuf
        if count==len(newbuf):
            return buf

def main():

    SetUp = cv2.FileStorage('SetUp4Server.xml', cv2.FileStorage_READ)
    if not SetUp.isOpened():
        print("error：NO SetUp.xml")
        return

    print("START...")
       server_ip = SetUp.getNode('Server_IP').string()
    print("ip：", server_ip)

    server_port = int(SetUp.getNode('Server_Port').real())
    print("IP：", server_port)


    SetUp.release()
    print("OK...")
    print("\n")

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        address = (server_ip, server_port)
    s.bind(address)      while True:

        s.listen(True)   
        print ('WAIT...')

     
        conn, addr = s.accept()
        print('SENT IMG..')
        while True:
            length = recv_size_1(conn,16)  
            #print(length)
            if isinstance(length, str):                  # print(int(length))
                if int(length)==9999:
                    break
                stringData = conn.recv(int(length),socket.MSG_WAITALL)
                #print(len(stringData))
                data =np.fromstring(stringData, np.uint8)
                # print(data.size)
                decimg = cv2.imdecode(data,cv2.IMREAD_COLOR)                  #print(decimg)
                cv2.imwrite("test.bmp",decimg)
                cv2.imshow('SERVER', decimg)
                if cv2.waitKey(10) == 27:
                    break
                #print('Image recieved successfully!')
        cv2.destroyAllWindows()
        print('CLOSE..')
        print("")
    s.close()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()