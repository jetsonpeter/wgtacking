import matplotlib.pyplot as plt
import networkx as nx
import yaml
from networkx.drawing.nx_pydot import write_dot
# Load the YAML file to parse its content
file_path = 'E:/yolov9-main-20240609/models/extra_s_dual/yolov9s-RepViT-P2.yaml'
with open(file_path, 'r', encoding='utf-8') as file:
    yaml_content = yaml.safe_load(file)

# Create a directed graph
G = nx.DiGraph()

# Add nodes and edges from the YAML content
for i, layer in enumerate(yaml_content['backbone']):
    G.add_node(f'backbone_{i}', label=f'{layer[2]}_{i}')
    if layer[0] != -1:
        G.add_edge(f'backbone_{layer[0]}', f'backbone_{i}')

for i, layer in enumerate(yaml_content['head']):
    G.add_node(f'head_{i}', label=f'{layer[2]}_{i}')
    if isinstance(layer[0], list):
        for src in layer[0]:
            G.add_edge(f'backbone_{src}' if src < len(yaml_content['backbone']) else f'head_{src - len(yaml_content["backbone"])}', f'head_{i}')
    else:
        G.add_edge(f'backbone_{layer[0]}' if layer[0] < len(yaml_content['backbone']) else f'head_{layer[0] - len(yaml_content["backbone"])}', f'head_{i}')

# Write the graph to a dot file
dot_path = "yolov9_graph.dot"
write_dot(G, dot_path)
