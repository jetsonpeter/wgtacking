yolov9ssc.pt--yolov9ssc.onnx
from ultralytics import YOLO
model = YOLO("best.pt")
output = model.export(format="onnx", simplify=True, dynamic=False, opset=12)
$ pip install onnx==1.15.0
$ pip install onnx-simplifier==0.4.35
$ git clone https://github.com/FeiYull/tensorrt-alpha
$ cd tensorrt-alpha/cmake
$ vim common.cmake
set (TensorRT_ROOT /usr/src/tensorrt）
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/src/tensorrt/lib 
/usr/src/tensorrt/bin/trtexec   --onnx=best.onnx  --saveEngine=best.trt  --fp16
/usr/src/tensorrt/bin/trtexec   --onnx=best.onnx  --saveEngine=best.trt  --int8
cd tensorrt-alpha/yolov8
vim app_yolov8.cpp
initParameters.class_names = utils::dataSets::ships;
initParameters.num_class = 1;
const std::vector<std::string> cotton = {"0"};
const std::vector<cv::Scalar> color1{
            cv::Scalar(148, 80, 189
        };
$ vim untils.cpp
if (classNames.size() == 1) 
{
	color = Colors::color1[box.label];
}
if (classNames.size() == 1)
{
	color = Colors::color1box.label];
}
cd tensorrt-alpha/yolov9ssc
mkdir build
cd build
cmake ..
make -j10
